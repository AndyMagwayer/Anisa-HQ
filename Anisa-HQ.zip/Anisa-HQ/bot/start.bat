@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist .env goto run
echo Первый запуск. Вставляйте значения правой кнопкой мыши и нажимайте Enter.
set /p TG=Токен бота от BotFather: 
set /p ID=Ваш ID от userinfobot: 
set /p KEY=Ключ Gemini из AI Studio: 
set /p GHT=Токен GitHub для Бруно, или Enter чтобы пропустить: 
> .env echo TELEGRAM_TOKEN=%TG%
>> .env echo OWNER_ID=%ID%
>> .env echo AI_API_KEY=%KEY%
>> .env echo AI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai
>> .env echo AI_MODEL=gemini-2.0-flash
>> .env echo TZ_NAME=Asia/Tashkent
>> .env echo TZ_OFFSET=+05:00
>> .env echo GITHUB_REPO=AndyMagwayer/Anisa-HQ
>> .env echo GITHUB_BRANCH=bruno-dev
if not "%GHT%"=="" >> .env echo GITHUB_TOKEN=%GHT%
:run
set NODE=node
where node >nul 2>nul || set NODE=C:\Users\f.qambarova\Downloads\node-v22.22.3-win-x64\node-v22.22.3-win-x64\node.exe
"%NODE%" --env-file=.env src/index.js
pause
